function onClick() {
    alert("Hello, world!");
}