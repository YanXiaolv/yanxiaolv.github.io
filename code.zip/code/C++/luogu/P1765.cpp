#include <iostream>
#include <string>
using namespace std;

int main() {
    string a;
    long long n;
    cin >> a;
    for (int i = 0; i < a.length(); i++) {
        if (a[i] == ' ' || a[i] == 'a' || a[i] == 'd' || a[i] == 'g' || a[i] == 'j' || a[i] == 'm' || a[i] == 'p' || a[i] == 't' || a[i] == 'w') {
            n++;
        } else if (a[i] == 'b' || a[i] == 'e' || a[i] == 'h' || a[i] == 'k' || a[i] == 'n' || a[i] == 'q' || a[i] == 'u' || a[i] == 'x') {
            n += 2;
        } else if (a[i] == 'c' || a[i] == 'f' || a[i] == 'i' || a[i] == 'l' || a[i] == 'o' || a[i] == 'r' || a[i] == 'v' || a[i] == 'y') {
            n += 3;
        } else if (a[i] == 's' || a[i] == 'z') {
            n += 4;
        }
    }
    cout << n << endl;
    return 0;
}