#include <iostream>
using namespace std;

void abc() {
    return;
}

int main() {
    int n, m;
    cin >> n >> m;
    int a[n + 2];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    return 0;
}