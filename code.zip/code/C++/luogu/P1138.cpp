#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> arr;
    for (int i = 0; i < n; i++) {
        int j;
        cin >> j;
        arr.push_back(j);
    }
    sort(arr.begin(), arr.end());
    /*
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << ' ';
    }
    cout << endl;
    */
    for (int i = 0; i < n; i++) {
        for (int j = i; j < n; j++) {
            if (j == i) {
                continue;
            }
            if (arr[i] == arr[j]) {
                arr.erase(arr.begin() + j);
                n--;
            }
        }
    }
    /*
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << ' ';
    }
    cout << endl;
    */
    cout << arr[2] << endl;
    return 0;
}