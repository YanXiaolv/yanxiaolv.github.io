from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello!这里是yanxiaolv的投票网站,欢迎你来这里参与我们的投票!")

def other(request):
    return HttpResponse("你访问了OTHER！")