import pygame
import random

# 初始化 Pygame
pygame.init()

# 设置屏幕尺寸和标题
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("日语单词背诵复习程序")

# 定义一些常量
FONT_SIZE = 36
FONT_COLOR = (255, 255, 255)
FONT_NAME = pygame.font.match_font('arial')
WORD_LIST = [
    {"word": "こんにちは", "translation": "你好"},
    {"word": "ありがとう", "translation": "谢谢"},
    {"word": "さようなら", "translation": "再见"},
    {"word": "おはよう", "translation": "早上好"},
    {"word": "おやすみ", "translation": "晚安"}
]

# 设置字体
font = pygame.font.Font(FONT_NAME, FONT_SIZE)

# 选择一个随机单词
current_word = random.choice(WORD_LIST)

# 主循环
running = True
while running:
    # 处理事件
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    # 清屏
    screen.fill((0, 0, 0))

    # 显示当前单词
    word_text = font.render(current_word["word"], True, FONT_COLOR)
    word_rect = word_text.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 50))
    screen.blit(word_text, word_rect)

    # 显示提示信息
    hint_text = font.render("请输入该单词的日语翻译：", True, FONT_COLOR)
    hint_rect = hint_text.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 + 50))
    screen.blit(hint_text, hint_rect)

    # 显示输入框
    input_box = pygame.Rect(SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 + 100, 200, 50)
    pygame.draw.rect(screen, FONT_COLOR, input_box, 2)

    # 处理用户输入
    if pygame.key.get_pressed()[pygame.K_RETURN]:
        # 获取用户输入的答案
        input_text = pygame.key.get_mods() and pygame.KMOD_SHIFT and pygame.key.name(event.key) or pygame.key.name(event.key).lower()
        if input_text == current_word["translation"]:
            # 如果回答正确，则选择另一个单词
            current_word = random.choice(WORD_LIST)
        else:
            # 如果回答错误，则重新显示相同的单词
            hint_text = font.render("回答错误，请重新输入：", True, FONT_COLOR)
            screen.blit(hint_text, hint_rect)

    # 显示更新后的画面
    pygame.display.flip()

# 退出 Pygame
pygame.quit()
