import pygame
import random
import string

# 初始化 pygame
pygame.init()

# 定义常量
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
FPS = 60

# 创建窗口
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Typing Game")

# 加载字体
font = pygame.font.Font(None, 50)

# 定义函数
def generate_word():
    """生成随机单词"""
    letters = string.ascii_lowercase
    word = "".join(random.choice(letters) for _ in range(5))
    return word

def draw_text(text, font, color, x, y):
    """在窗口上绘制文本"""
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (x, y)
    window.blit(text_surface, text_rect)

# 初始化变量
word = generate_word()
score = 0

# 创建游戏循环
clock = pygame.time.Clock()
running = True
while running:
    # 处理事件
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.unicode == word[0]:
                word = word[1:]
                if not word:
                    score += 1
                    word = generate_word()
    # 绘制界面
    window.fill(WHITE)
    draw_text(word, font, BLACK, WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2)
    draw_text(f"Score: {score}", font, BLACK, 100, 50)
    # 更新屏幕
    pygame.display.flip()
    # 控制游戏速度
    clock.tick(FPS)

# 退出 pygame
pygame.quit()
