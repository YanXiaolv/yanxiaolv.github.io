import math
n = int(input("n = "))

x = {}
a = 0
b = 0
for i in range(n):
    x[i] = int(input("x[i] = "))
    a += x[i]
a /= n
for j in range(n):
    b += ((x[j] - a) * (x[j] - a))
b *= 1/n
c = math.sqrt(b)
print("Standard Deviation = ",c)