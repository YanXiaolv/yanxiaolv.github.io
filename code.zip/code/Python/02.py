import openai_secret_manager

assert "openai" in openai_secret_manager.get_services()
secrets = openai_secret_manager.get_secret("openai")

import openai
openai.api_key = secrets["api_key"]

def generate_news_report(topic):
    prompt = (f"In recent news, {topic} has been the subject of much discussion. Many people are wondering what the future holds for this "
              "important issue. Here is a news report summarizing the latest developments.\n\n")

    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        temperature=0.5,
        max_tokens=2048,
        n=1,
        stop=None,
        timeout=60,
    )

    return response.choices[0].text

a = input("> ")
print(generate_news_report(a))